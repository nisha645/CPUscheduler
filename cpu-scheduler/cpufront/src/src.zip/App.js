import React, { useState } from "react";
import "./App.css";

const App = () => {
  const [algorithm, setAlgorithm] = useState("FCFS");
  const [quantum, setQuantum] = useState("");
  const [processes, setProcesses] = useState([]);
  const [pid, setPid] = useState("");
  const [arrival, setArrival] = useState("");
  const [burst, setBurst] = useState("");
  const [priority, setPriority] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const addProcess = () => {
    if (!pid || arrival === "" || burst === "") {
      setError("All fields except priority are required");
      return;
    }

    if (processes.find((p) => p.pid === pid)) {
      setError("Duplicate PID not allowed");
      return;
    }

    const newProcess = {
      pid,
      arrival_time: Number(arrival),
      burst_time: Number(burst),
      priority: Number(priority) || 0,
    };
    setProcesses([...processes, newProcess]);
    setPid("");
    setArrival("");
    setBurst("");
    setPriority("");
    setError("");
  };

  const clearAll = () => {
    setProcesses([]);
    setResult(null);
    setError("");
  };

  const simulate = async () => {
    if (!algorithm) {
      setError("Select an algorithm");
      return;
    }

    if (algorithm === "Round Robin" && (quantum === "" || isNaN(quantum))) {
      setError("Quantum must be a valid number for Round Robin");
      return;
    }

    const response = await fetch("http://127.0.0.1:5000/schedule", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        processes,
        algorithm,
        quantum: quantum || "2",
      }),
    });

    const data = await response.json();
    if (data.error) {
      setError(data.error);
    } else {
      setResult(data);
      setError("");
    }
  };

  const avgWaiting =
    result &&
    (
      result.metrics.reduce((acc, cur) => acc + cur.waiting_time, 0) /
      result.metrics.length
    ).toFixed(2);

  const avgTurnaround =
    result &&
    (
      result.metrics.reduce((acc, cur) => acc + cur.turnaround_time, 0) /
      result.metrics.length
    ).toFixed(2);

  const getColorForPid = (pid) => {
    const colors = [
      "#0074D9", "#FF851B", "#2ECC40", "#B10DC9",
      "#FF4136", "#39CCCC", "#FFDC00", "#85144b",
      "#3D9970", "#7FDBFF"
    ];
    const index = parseInt(pid, 10) % colors.length;
    return colors[index];
  };

  return (
    <div className="app">
      <h1>CPU SCHEDULER</h1>

      <div className="controls">
        <label>
          Algorithm:
          <select value={algorithm} onChange={(e) => setAlgorithm(e.target.value)}>
            <option>FCFS</option>
            <option>SJF</option>
            <option>Priority</option>
            <option>Round Robin</option>
          </select>
        </label>

        {algorithm === "Round Robin" && (
          <input
            placeholder="Quantum"
            value={quantum}
            onChange={(e) => setQuantum(e.target.value)}
            className="quantum"
          />
        )}

        <button onClick={simulate}>Run</button>
        <button onClick={addProcess}>+ Add Process</button>
        <button onClick={clearAll}>Clear All</button>
      </div>

      <div className="form-row">
        <input
          placeholder="PID"
          value={pid}
          onChange={(e) => setPid(e.target.value)}
        />
        <input
          placeholder="Arrival"
          value={arrival}
          type="number"
          onChange={(e) => setArrival(e.target.value)}
        />
        <input
          placeholder="Burst"
          value={burst}
          type="number"
          onChange={(e) => setBurst(e.target.value)}
        />
        <input
          placeholder="Priority (opt)"
          value={priority}
          type="number"
          onChange={(e) => setPriority(e.target.value)}
        />
      </div>

      {error && <div className="error">{error}</div>}

      <table>
        <thead>
          <tr>
            <th>PROCESS</th>
            <th>ARRIVAL TIME</th>
            <th>BURST TIME</th>
          </tr>
        </thead>
        <tbody>
          {processes.map((p, i) => (
            <tr key={i}>
              <td>P{p.pid}</td>
              <td>{p.arrival_time}</td>
              <td>{p.burst_time}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {result && (
        <>
          <h2>Results</h2>
          <table>
            <thead>
              <tr>
                <th>PROCESS ID</th>
                <th>ARRIVAL TIME</th>
                <th>BURST TIME</th>
                <th>COMPLETION TIME</th>
                <th>TURNAROUND TIME</th>
                <th>WAITING TIME</th>
              </tr>
            </thead>
            <tbody>
              {result.metrics.map((p, i) => (
                <tr key={i}>
                  <td>P{p.pid}</td>
                  <td>{p.arrival_time}</td>
                  <td>{p.burst_time}</td>
                  <td>{p.completion_time}</td>
                  <td>{p.turnaround_time}</td>
                  <td>{p.waiting_time}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="averages">
            <p><strong>Avg Waiting Time:</strong> {avgWaiting}</p>
            <p><strong>Avg Turnaround Time:</strong> {avgTurnaround}</p>
          </div>

      <div className="gantt-section">
            <h2>Gantt Chart</h2>

            <div className="gantt-chart-container">
              <div className="gantt-chart">
                {(() => {
                  const chart = [];
                  let currentTime = 0;

                  for (let i = 0; i < result.gantt.length; i++) {
                    const block = result.gantt[i];
                    const gap = block.start - currentTime;

                    if (gap > 0) {
                      chart.push(
                        <div
                          className="gantt-block idle"
                          key={`idle-${i}`}
                          data-tooltip={`Idle (${currentTime}–${block.start})`}
                          style={{ width: `${gap * 30}px` }}
                        >
                          <span>Idle</span>
                        </div>
                      );
                    }

                    const blockWidth = (block.end - block.start) * 30;

                    chart.push(
                      <div
                        className="gantt-block"
                        key={i}
                        data-tooltip={`P${block.pid} (${block.start}–${block.end})`}
                        style={{
                          width: `${blockWidth}px`,
                          backgroundColor: getColorForPid(block.pid),
                        }}
                      >
                        <span>P{block.pid}</span>
                      </div>
                    );

                    currentTime = block.end;
                  }

                  return chart;
                })()}
              </div>

              <div className="gantt-timeline">
                {(() => {
                  const timeline = [];
                  let currentTime = 0;

                  for (let i = 0; i < result.gantt.length; i++) {
                    const block = result.gantt[i];

                    if (block.start > currentTime) {
                      timeline.push(
                        <span
                          key={`time-${currentTime}`}
                          className="time-marker"
                          style={{ width: `${(block.start - currentTime) * 30}px` }}
                        >
                          {currentTime}
                        </span>
                      );
                    }

                    timeline.push(
                      <span
                        key={`time-${block.start}`}
                        className="time-marker"
                        style={{ width: `${(block.end - block.start) * 30}px` }}
                      >
                        {block.end}
                      </span>
                    );

                    currentTime = block.end;
                  }

                  return timeline;
                })()}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default App;
